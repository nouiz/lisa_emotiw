% HISTOGRAMS
%
% Files
%   fitt_distribution  - The function fitts a predefined distribution to the histogram of an image.
%   rank_normalization - The function performs rank normalization on an image - histogram equalization.
